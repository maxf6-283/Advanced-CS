import gui.Frame;

public class Runner {
    public static void main(String[] args) {
        new Frame();
    }
}