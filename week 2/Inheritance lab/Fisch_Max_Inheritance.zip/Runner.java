public class Runner {
    public static void main(String[] args) {
        Screen screen = new Screen();
        screen.setSize(1000, 800);
        screen.setResizable(false);
        screen.setVisible(true);
    }
}
