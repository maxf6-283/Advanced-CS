public class Runner {
    public static void main(String[] args) {
        Screen screen = new Screen();

        screen.setBounds(100, 100, 300, 700);
        screen.setResizable(false);
        screen.setVisible(true);
    }
}
