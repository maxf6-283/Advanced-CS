public class Student {
    private String name;

    public Student(String n) {
        name = n;
    }

    @Override
    public String toString() {
        return name;
    }
}
